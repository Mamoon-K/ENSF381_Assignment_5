const testimonials = [
  {
    studentName: "Alice Johnson",
    courseName: "Web Development",
    review: "Excellent course structure!",
    rating: 5
  },
  {
    studentName: "Mark Rivera",
    courseName: "Machine Learning",
    review: "Challenging but super rewarding!",
    rating: 4
  },
  {
    studentName: "Nina Gupta",
    courseName: "Database Systems",
    review: "Helped me land my internship!",
    rating: 5
  },
  {
    studentName: "Chris Thompson",
    courseName: "Cybersecurity Fundamentals",
    review: "Very informative with real-world examples.",
    rating: 4
  }
];

export default testimonials;
